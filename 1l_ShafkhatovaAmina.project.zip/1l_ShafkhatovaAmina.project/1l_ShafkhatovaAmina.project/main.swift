import Foundation

print("Задание 1")

var a:Double = 2
var b:Double = 4
var c:Double = 2;
var d = pow(b, 2) - 4*a*c;

if (d > 0) {
    let x1 = (-b + sqrt(d)) / 2 / a
    let x2 = (-b - sqrt(d)) / 2 / a
    print("Первый корень уравнения = \(x1)/")
    print("Второй корень уравнения = \(x2)/")
}
else if (d == 0) {
    let x = -b / 2 / a
    print("Корень уравнения = \(x)") }
else {
    print("Уравнение не имеет действительных решений")
}


print("Задание 2")

var sideA:Double = 10
var sideB:Double = 8
var hypotenuse = sqrt(pow(sideA, 2) + pow(sideB, 2))

print("Гипотенуза = \(hypotenuse)")
print("Периметр = \(sideA + sideB + hypotenuse)")
print("Площадь = \(sideA * sideB / 2)")


print("Задание 3")

print("Сумма вклада:")
let initialDeposit = Double(readLine()!)!
print("Годовой процент:")
let percentage = Double(readLine()!)!

var depositWithoutCapitalization = initialDeposit + initialDeposit * percentage / 100 * 5
var depositWithMonthlyCap = initialDeposit * pow(1 + percentage / 100 / 12, 60)
var depositWithQuarterlyCap = initialDeposit * pow(1 + percentage / 100 / 4, 20)
var depositWithAnnualCap = initialDeposit * pow(1 + percentage / 100, 5)

print("Сумма вклада без учета капитализации = \(depositWithoutCapitalization)")
print("Сумма вклада с учетом ежемесячной капитализации = \(depositWithMonthlyCap)")
print("Сумма вклада с учетом ежеквартальной капитализации = \(depositWithQuarterlyCap)")
print("Сумма вклада с учетом ежегодной капитализации = \(depositWithAnnualCap)")
